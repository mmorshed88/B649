#!/usr/bin/env bash

:<<COMMENT
echo "Setting Hadoop path to environment"
cp ~/.bashrc ~/.bashrc.bak
echo "export HADOOP_HOME=$1" >> ~/.bashrc
echo "export HADOOP_YARN_HOME=$1" >> ~/.bashrc
HADOOP_HOME=$1
HADOOP_YARN_HOME=$1
echo "export HADOOP_PREFIX=$HADOOP_HOME" >> ~/.bashrc
HADOOP_PREFIX=$HADOOP_HOME
echo "export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop" >> ~/.bashrc
HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
echo "export PATH=$HADOOP_HOME/sbin:/$HADOOP_HOME/bin:$PATH" >> ~/.bashrc
PATH=$HADOOP_HOME/sbin:/$HADOOP_HOME/bin:$PATH
source ~/.bashrc
COMMENT

$HADOOP_PREFIX/bin/hadoop --config $HADOOP_CONF_DIR namenode -format -force
sleep 1
$HADOOP_PREFIX/sbin/hadoop-daemon.sh --config $HADOOP_CONF_DIR --script hdfs start namenode
sleep 1
$HADOOP_PREFIX/sbin/hadoop-daemons.sh --config $HADOOP_CONF_DIR --script hdfs start datanode
sleep 1
$HADOOP_YARN_HOME/sbin/yarn-daemon.sh --config $HADOOP_CONF_DIR start resourcemanager
sleep 1
$HADOOP_YARN_HOME/sbin/yarn-daemons.sh --config $HADOOP_CONF_DIR start nodemanager
sleep 10
